﻿using SearchFight.Core;
using SearchFight.Services;
using SearchFight.Utilities;
using System;
using System.Linq;

namespace SearchFight
{
    class Program{
        static void Main(string[] args){
            try{
                string Keywords = "java \"java script\" .net";
                Console.WriteLine("Please enter your key words between ' '");
                //string strKeywords = Console.ReadLine();

                ////Split Readline to Keywords
                //var arrKeyWords = Regex.Matches(strKeywords, @"[\""].+?[\""]|[^ ]+").Cast<Match>().Select(m => m.Value).ToList();

                ////Validate arrKeyWords if it has two words minimum
                //if (arrKeyWords.Count < 2){
                //    Console.WriteLine("You need enter two languages at least.");
                //    return;
                //}
                //Run the search
                var runners = GetFinders.ReadConfiguration("FilePathXML").SearchRunners.Where(runner => !runner.Disabled).ToList();
                //Get Collect results 
                var results = Results.CollectResults(Keywords, runners).Result;           
                //Print results
                ConsoleHelpers.PrintAsTable(results.Languages, results.Runners, results.Counts, results.Winners, results.Winner, "{0:#,#}");
            }
            catch (ConfigurationException ex){
                Console.WriteLine();
                Console.WriteLine(ex.Message);
            }
            catch (AggregateException ex){
                ex.Handle(e => {
                    var searchException = e as SearchException;
                    if (searchException != null){
                        Console.WriteLine();
                        Console.WriteLine(string.Format("Runner '{0}' failed. {1}", searchException.Runner, searchException.Message));
                        return true;
                    }
                    else
                        return false;
                });
            }
            catch (Exception ex){
                Console.WriteLine();
                Console.WriteLine("An unexpected exception has occurred: " + Environment.NewLine + ex.ToString());
            }           
            Console.Read();
        }     
    }
}