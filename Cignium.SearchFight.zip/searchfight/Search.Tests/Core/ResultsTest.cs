﻿using NUnit.Framework;
using SearchFight.Core;
using SearchFight.Services;
using SearchFight.Utilities;
using System.Collections.Generic;
using System.Linq;

namespace Search.Tests
{
    [TestFixture]
    public class ResultsTest {
        [Test]     
        public void GetSearchResult_ConfigurationException(){
            string Keywords = null;          
            Assert.ThrowsAsync<ConfigurationException>(() => Results.CollectResults(Keywords, null));
        }        

        [Test]
        [TestCase("java \"java script\" .net", "FilePathXML")]
        public void GetSearchResults_Success(string Keywords,string FilePath){
            var runners = GetFinders.ReadConfiguration(FilePath).SearchRunners.Where(runner => !runner.Disabled).ToList();

            var results = Results.CollectResults(Keywords, runners).Result;
            
            Assert.IsNotNull(results);
            Assert.AreNotEqual(results.Counts.Length, 0);          
        }

        [Test]
        public void GetWinnersResults_Success(){
            Results oResults = new Results();

            var myRunners = new List<string>();         
            myRunners.Add("Yahoo");
            myRunners.Add("MSN Search");

            var myLanguages = new List<string>();
            myLanguages.Add("Java");
            myLanguages.Add(".net");

            var arrCounts = new long[2,2];          
            arrCounts[0, 0] = 1850698;
            arrCounts[0, 1] = 60100000;
            arrCounts[1, 0] = 50200000;
            arrCounts[1, 1] = 17900000;

            oResults.Runners = myRunners;
            oResults.Languages = myLanguages;
            oResults.Counts = arrCounts;

            var Winners = oResults.GetWinners();
         
            Assert.AreEqual(Winners[0].Value, ".net");
            Assert.AreEqual(Winners[1].Value, "Java");
        }


        [Test]
        public void GetTotalWinnerResult_Success(){
            Results oResults = new Results();

            var myRunners = new List<string>();
            myRunners.Add("Yahoo");
            myRunners.Add("MSN Search");

            var myLanguages = new List<string>();
            myLanguages.Add("Java");
            myLanguages.Add(".net");

            var arrCounts = new long[2, 2];
            arrCounts[0, 0] = 1850698;
            arrCounts[0, 1] = 60100000;
            arrCounts[1, 0] = 50200000;
            arrCounts[1, 1] = 17900000;

            oResults.Runners = myRunners;
            oResults.Languages = myLanguages;
            oResults.Counts = arrCounts;

            var TotalWinner = oResults.GetWinner();

            Assert.AreEqual(TotalWinner, ".net");            
        }
    }
}
