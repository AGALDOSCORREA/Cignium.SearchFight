﻿using NUnit.Framework;
using SearchFight.Services;
using SearchFight.Utilities;

namespace Search.Tests.Services
{
    [TestFixture]
    class GetFindersTest
    {

        [Test]
        [TestCase(null)]
        public void GetExceptionPathFile_XMLSearchRunners_ConfigurationException(string FilePath){ 
            Assert.Throws<ConfigurationException>(() => GetFinders.ReadConfiguration(FilePath));
        }       

    }
}
