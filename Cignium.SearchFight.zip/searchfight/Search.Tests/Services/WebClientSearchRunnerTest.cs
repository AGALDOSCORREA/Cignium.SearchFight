﻿using NUnit.Framework;
using SearchFight.Services;
using SearchFight.Utilities;

namespace Search.Tests.Services
{
    [TestFixture]
    class WebClientSearchRunnerTest{
        [Test]
        [TestCase("java")]
        public void GetExceptionBuildUri_ConfigurationException(string KeyWord){           
            WebClientSearchRunner oWebClientSearchRunner = new WebClientSearchRunner();

            oWebClientSearchRunner.Address = "";
            oWebClientSearchRunner.QueryName = "p";
            
            Assert.Throws<ConfigurationException>(() => oWebClientSearchRunner.BuildUri("Java"));
        }
    }
}
