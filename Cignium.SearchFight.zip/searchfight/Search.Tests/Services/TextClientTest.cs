﻿using NUnit.Framework;
using SearchFight.Services;
using SearchFight.Utilities;
using System;
using System.Threading.Tasks;

namespace Search.Tests{
    [TestFixture]
    public class TextClientTest{
        public TextClient Client { get; set; }

        [Test]
        [TestCase("https://en-maktoob.search.yahoo.com/search?p=java")]
        public async Task GetResponseText_Success(string uri){           
            StringDictionary Headers = null;
            var uriBuilder = new UriBuilder(uri);
            var responseText = await (Client ?? TextClient.Default).GetResponseText(uriBuilder.Uri, Headers);
                       
            Assert.IsNotNull(responseText);
            Assert.IsNotEmpty(responseText);           
        }        
    }
}
