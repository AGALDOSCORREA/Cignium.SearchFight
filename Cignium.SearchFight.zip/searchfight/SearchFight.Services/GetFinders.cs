﻿using SearchFight.Utilities;
using System;
using System.IO;
using System.Xml.Serialization;
namespace SearchFight.Services{
    public static class GetFinders{
        public static Configuration ReadConfiguration(string FilePath){
            try{
                string FilePathXML = System.Configuration.ConfigurationManager.AppSettings[FilePath];
                using (FileStream xmlFile = File.OpenRead(FilePathXML)){
                    try{
                        var serializer = new XmlSerializer(typeof(Configuration));
                        return (Configuration)serializer.Deserialize(xmlFile);
                    }
                    catch (InvalidOperationException ex){
                        throw new ConfigurationException("The configuration file is invalid. " + ex.Message, ex);
                    }
                }
            }
            catch (UnauthorizedAccessException ex){
                throw new ConfigurationException("Unauthorized exception trying to access cofiguration file.", ex);
            }
            catch (FileNotFoundException ex){
                throw new ConfigurationException("Could not find configuration file.", ex);
            }
            catch (IOException ex){
                throw new ConfigurationException("An error occurred when reading configuration file.", ex);
            }
            catch (Exception ex){
                throw new ConfigurationException("An unexpected exception has occurred: " + Environment.NewLine + ex.ToString());                
            }
        }    
   }
}